/** Automatically generated file. DO NOT MODIFY */
package com.example.assignment1_bose;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}