package com.example.assignment1_bose;

import java.io.IOException;
import org.apache.http.client.HttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import android.os.AsyncTask;

public class NetworkTask extends AsyncTask<String, Void, String> {
	String countryInput;
	MainActivity mainact_;

	public NetworkTask(MainActivity main) {
		mainact_ = main;
	}

	@Override
	protected String doInBackground(String... params) {
		try {
			HttpClient httpclient_ = new DefaultHttpClient();
			HttpGet httpget_ = new HttpGet(
					"http://www.countries-ofthe-world.com/capitals-of-the-world.html");
			HttpResponse response_ = httpclient_.execute(httpget_);
			HttpEntity entity_ = response_.getEntity();
			countryInput = EntityUtils.toString(entity_);

		} catch (IOException e) {
			e.printStackTrace();
		}
		int startCity = -1;
		String withinHtml = "";
		String takeData = "";
		String countryString = params[0];
		startCity = countryInput.indexOf(countryString + " - ");
		if (startCity != -1) {
			withinHtml = countryInput.substring(startCity
					+ (countryString + " - ").length());
			takeData = withinHtml.substring(0, withinHtml.indexOf("</li>"));
			return takeData;
		} else {
			return "Enter a valid country!";
		}
	}

	@Override
	protected void onPostExecute(String para_result) {
		mainact_.setCapital(para_result);
	}
}
