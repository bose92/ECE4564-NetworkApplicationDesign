/** Automatically generated file. DO NOT MODIFY */
package com.example.assignment1_curtis;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}