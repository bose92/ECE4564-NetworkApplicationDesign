package com.example.assignment1_bose;

import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import com.example.assignment1_curtis.R;

public class MainActivity extends Activity {
	private Button getCapital_;
	private EditText country_;
	private TextView showCapital_;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		showCapital_ = (TextView) findViewById(R.id.loading);
		getCapital_ = (Button) findViewById(R.id.getschedule);
		country_ = (EditText) findViewById(R.id.editText_opp);
		doConcurrencyNetworkOperation();
	}

	public void doConcurrencyNetworkOperation() {
		OnClickListener listener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				String UserInput_ = country_.getText().toString();
				final NetworkTask myTask = new NetworkTask(MainActivity.this);
				myTask.execute(UserInput_);
			}
		};

		getCapital_.setOnClickListener(listener);
	}

	public void setCapital(String value) {
		showCapital_.setText(value);
	}
}